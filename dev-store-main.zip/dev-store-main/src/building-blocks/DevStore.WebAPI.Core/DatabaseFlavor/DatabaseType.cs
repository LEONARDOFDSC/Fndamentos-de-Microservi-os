﻿namespace DevStore.WebAPI.Core.DatabaseFlavor;

public enum DatabaseType
{
    None,
    SqlServer,
    MySql,
    Postgre,
    Sqlite,
}